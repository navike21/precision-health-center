<?php
	$link = mysqli_connect("localhost", "adretail_ivan", "Server2003", "adretail_quinde");

	if (mysqli_connect_errno()) {
		printf("Error de conexión: %s\n", mysqli_connect_error());
		exit();
	}
?>
