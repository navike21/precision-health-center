# Formulario El Quinde #

Formulario para recopilar información para el Quinde de Cajamarca e Ica.

### Información Adicional ###

* Html5 / Css3 / Jquery
* Php / Mysql
* Responsive Design

### Librerías Adicionales ###

* Bastemp.